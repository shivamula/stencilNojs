import { Component, h } from '@stencil/core';

@Component({
  tag: 'home-page'
})
export class HomePage {
  render() {
    return <h2>I'm the home page</h2>;
  }
}
