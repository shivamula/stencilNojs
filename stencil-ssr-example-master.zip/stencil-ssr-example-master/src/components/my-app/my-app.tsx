import { Component, h } from '@stencil/core';
import '@stencil/router';

@Component({
  tag: 'my-app',
  styleUrl: 'my-app.css'
})
export class MyApp {
  render() {
    return [
    
        <div class="imageMainBackGround">
      <div id="myModal" class="modal">    
        <div class="modal-content">
          <div class="row">
          <div class="column1 imageBackGround"></div>
          <div class="column2">dds</div>
          </div>
        </div>
        </div>
      </div>
    ];  }
}
