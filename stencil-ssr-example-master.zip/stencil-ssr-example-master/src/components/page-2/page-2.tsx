import { Component, h } from '@stencil/core';

@Component({
  tag: 'page-2'
})
export class Page2 {
  render() {
    return <h2>I'm Page #2</h2>;
  }
}
